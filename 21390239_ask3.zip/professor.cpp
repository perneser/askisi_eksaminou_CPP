#include "professor.h"
#include <string>
#include <iostream>

std::ostream& operator<<(std::ostream &os, const Professor &p)
{
    p.print(os);
    return os;
}

// Constructors
Professor::Professor (const char* _AM, std::string _fullname, std::string _gender, std::string _specialty)
                    : Person(_AM,_fullname, _gender),                                specialty(_specialty)
{
}

// Destructor
Professor::~Professor()
{
}

// Getter
std::string Professor::getSpecialty() const
{
    return specialty;
}

// Εμφάνιση των χαρακτηριστικών του καθηγητή
void Professor::print(std::ostream& os) const
{
    Person::print(os);
    os << " | Ειδικότητα: " << this->getSpecialty();
}
