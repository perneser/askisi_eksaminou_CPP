#include "registry.h"
#include <iostream>
#include "student.h"
#include "professor.h"
#include "person.h"
#include <cstring>
#include "course.h"


std::vector<const Person*> Registry::getPersons() const
{
    return persons;
}

std::vector<const Student*> Registry::getStudents()const
{
    std::vector<const Student*> students;
    for (const Person *person : persons)
    {
        // Εάν το άτομο είναι φοιτητής
        const Student* student = dynamic_cast<const Student*>(person);
        if (student != nullptr)
            students.push_back(student);
    }
    return students;
}
std::vector<const Professor*> Registry::getProfessors()const
{
    std::vector<const Professor*> professors;
    for (const Person *person : persons)
    {
        // Εάν το άτομο είναι φοιτητής
        const Professor* professor = dynamic_cast<const Professor*>(person);
        if (professor != nullptr)
            professors.push_back(professor);
    }
    return professors;
}

std::vector<Course> Registry::getCourses()const
{
    return courses;
}


void Registry::addPerson(const Person &constPerson)
{
    persons.push_back(&constPerson);
}    

/*
// Διόρθωση μέλους τους τμήματος - πήρα την συνάρτηση από την περσυνή μου άσκηση, 
// δεν πρόλαβα να την επεξεργαστώ πλήρως ώστε να είναι χρησιμοποιήσιμη 
void Registry::updatePerson(const char* keyPersonAM, const Person &in_person)
{
	// Για κάθε μέλος του φοιτητολογίου
	for (const auto &person: persons)
	{
		// Εάν ο εισαγόμενος αριθμός ταυτότητας (κλειδί) ταυτίζεται με τον
		// αριθμό ταυτότητας του συγκεκριμένου μέλους του φοιτητολογίου
		if ( strcmp(keyPersonAM, person->getAM()) ==  0 )
		{
			// Αντικατάσταση των τιμών των base class (Person) attributes 
			// του μέλους του φοιτητολογίου
			person->setAM(in_person.getAM());
			person->setFullname(in_person.getFullname());
			person->setGender(in_person.getGender());
            person->setCourses(in_person.getCourses());

			// Εάν το συγκεκριμένο μέλος του φοιτητολογίου είναι φοιτητής
			// και επιπλέον το εισαγόμενο μέλος (in_person) είναι φοιτητής
			Student *student = dynamic_cast <Student *> (person);
			Student *in_student = dynamic_cast <Student *>  ( const_cast<Person*>(&in_person) );
			if (student != NULL && in_student != NULL)
			{
				// Αντικαστάσταση των derived class (Student) attributes 
				// του μέλους του φοιτητολογίου
				student->setSemester(in_student->getSemester());
			}
			// Εάν το συγκεκριμένο μέλος του φοιτητολογίου είναι καθηγητής
			// και επιπλέον το εισαγόμενο μέλος (in_person) είναι καθηγητής
			Professor *professor = dynamic_cast <Professor *> (person);
			Professor *in_professor = dynamic_cast <Professor *> ( const_cast<Person*>(&in_person) );
			if (professor != NULL && in_professor != NULL)
			{
				// Αντικαστάσταση των derived class (Professor) attributes 
				// του μέλους του φοιτητολογίου
				professor->setSpecialty(in_professor->getSpecialty());
			}
		}
	}
}
*/

// Διαγραφή φοιτητή/καθηγητή από τον κατάλογο
void Registry::removePerson(const Person &in_person)
{
    for (auto it = persons.begin(); it != persons.end(); ++it)
    {
        if ( strcmp((*it)->getAM(), in_person.getAM()) == 0 )
        {
            persons.erase(it); // Διαγραφή μέσω του iterator
            break;
        }    
    }    
}

void Registry::createCourse(const Course &course)
{
    courses.push_back(course);
}

// Διαγραφή μαθηματος από τον κατάλογο
void Registry::removeCourse(const Course &in_course)
{
    for (auto it = courses.begin(); it != courses.end(); ++it)
    {
        if ( (*it).getID() == in_course.getID())
        {
            courses.erase(it); // Διαγραφή μέσω του iterator
            break;
        }    
    }    
}

// Διόρθωση μαθήματος στο φοιτητολόγιο
void Registry::updateCourse(std::string keyCourseID,
	std::string in_ID,
	std::string in_description,
	unsigned int in_semester,
	Professor *in_mainProfessor)
{
	// Για κάθε ακαδημαϊκό μάθημα του φοιτητολογίου
	for (auto &course : courses) 
	{
		if (keyCourseID == course.getID())
		{
			course.setID(in_ID);
			course.setDescription(in_description);
			course.setSemester(in_semester);
			course.setMainProfessor(in_mainProfessor);
		}
	}
}

// Εμφάνιση ατόμων εγγεγραμένων στο φοιτητολόγιο
void Registry::printPersons()const
{
    for (const Person *person : persons)
    {
        if (person->isStudent())
        {
            if (person->isFemale())
                std::cout << "Φοιτήτρια | ";
            else
                std::cout << "Φοιτητής | ";

        }    
        else if (person->isProfessor())
        {
            if (person->isFemale())
                std::cout << "Καθηγήτρια | ";
            else
                std::cout << "Καθηγητής | ";
        }     
        
        std::cout << *person << std::endl;
    }    
    
}    

void Registry::printCourses()const
{
    for (auto course : courses)
    {
        std::cout << course << std::endl;
    }
}

// Αποστολή email σε όλους τους καθηγητές / όλες τις καθηγήτριες του τμήματος
void Registry::sendEmailToAllProfessors() const
{
	for (const auto &person: persons)
	{
		const Professor *professor = dynamic_cast <const Professor *> (person);
		if (professor != NULL)
		{
			std::cout << "Στάλθηκε email " 
                      <<  ((professor->isFemale())? "στην καθηγήτρια ": "στον καθηγητή " ) // Φυλετική διάκριση
                      << professor->getFullname() << std::endl;
		}
	}
}

// Αποστολή email σε όλους τους φοιτητές / όλες τις φοιτήτριες του τμήματος
void Registry::sendEmailToAllStudents() const
{
	for (const auto &person: persons)
	{
		const Student *student = dynamic_cast <const Student *> (person);
		if (student != NULL)
		{
			std::cout << "Στάλθηκε email " 
                      <<  ((student->isFemale())? "στην φοιτήτρια ": "στον φοιτητή " ) // Φυλετική διάκριση
                     << student->getFullname() << std::endl;
		}
	}
}