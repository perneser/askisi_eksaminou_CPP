#ifndef REGISTRY_H
#define REGISTRY_H

#include <list>
#include <vector>
#include <string>

class Person;
class Course;
class Student;
class Professor;


/// Ενδεχομένως να το κάνω singleton αργότερα;
class Registry
{
    private:
        // Ενιαίος κατάλογος των μελών του τμήματος (φοιτητές, καθηγητές) 
        std::vector<const Person*> persons;   ///Να βγάλω το const?

        // Κατάλογος των μαθημάτων
        std::vector<Course> courses;    // Composition
    public:
        // Getters
        std::vector<const Person*> getPersons()const;

        // Getters για προηγούμενη υλοποίηση του προγράμματος
        std::vector<const Student*> getStudents()const;
        std::vector<const Professor*> getProfessors()const;


        std::vector<Course> getCourses()const;
    
        // Εισαγωγή φοιτητή/καθηγητή στο φοιτητολόγιο
        void addPerson(const Person &person);
        // Δημιουργια μαθήματος
        void createCourse(const Course &course);

        // Διαγραφή φοιτητή/καθηγητή από τον κατάλογο
        void removePerson(const Person &person);
        // Διαγραφή μαθηματος από τον κατάλογο
        void removeCourse(const Course &course);

        // Διόρθωση μαθήματος στο φοιτητολόγιο
  		void updateCourse(std::string keyCourseID,
			std::string _ID,
			std::string _name,
			unsigned int _semester,
			Professor *_professorPtr
		);

        void updatePerson(const char* keyMemberAM, const Person &in_person);


        // Εμφάνιση ατόμων εγγεγραμένων στο φοιτητολόγιο
        void printPersons()const;
        
        // Εμφάνιση μαθημάτων που υπάρχουν στο φοιτητολόγιο
        void printCourses()const;

        // Αποστολή e-mail σε όλους τους εκπαιδευτικούς
        void sendEmailToAllProfessors()const;
        // Αποστολή e-mail σε όλους τους φοιτητές
        void sendEmailToAllStudents()const;

    };

#endif