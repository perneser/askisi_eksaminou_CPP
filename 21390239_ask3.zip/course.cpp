#include "course.h"
#include "professor.h"
#include <string>
#include "registry.h"
#include <iostream>

std::ostream& operator<<(std::ostream &os, const Course &c)
{
    c.print(os);
    return os;
}


Course::Course(std::string _ID, std::string _description, unsigned int _semester)
            :          ID(_ID), description(_description),    semester(_semester)
{

}

Course::Course(std::string _ID, std::string _description, unsigned int _semester, Professor * _mainProfessor)
            :          ID(_ID), description(_description),    semester(_semester), mainProfessor(_mainProfessor)
    
{
}

Course::~Course()
{

}

std::string Course::getID() const
{
    return ID;
}

std::string Course::getDescription() const
{
    return description;
}

unsigned int Course::getSemester() const
{
    return semester;
}

Professor* Course::getMainProfessor() const
{
    return mainProfessor;
}

void Course::setID(std::string _ID)
{
    ID = _ID;
}

void Course::setDescription(std::string _description)
{
    description = _description;
}

void Course::setSemester(unsigned int _semester)
{
    semester = _semester;
}

void Course::setMainProfessor(Professor *_mainProfessor)
{
    mainProfessor = _mainProfessor;
}

void Course::print(std::ostream &os) const
{
    os << "Κωδικός: " << this->getID()
    << " | Περιγραφή: " << this->getDescription()
    << " | Εξάμηνο διδασκαλίας: " << this->getSemester()
    << " | Υπεύθυνος μαθήματος: " << (this->getMainProfessor())->getFullname();
}