// compiled with: g++ main.cpp person.cpp student.cpp professor.cpp course.cpp myException.cpp registry.cpp -o main.o
#include "student.h"
#include "professor.h"
#include "course.h"
#include "registry.h"

#include <iostream>
#include <string>
#include <cstring>

using namespace std;

// try-catch block in: person.cpp

int main() {

    
    Registry services; //Δημιουργία φοιτητολογίου

    //Δημιουργία δυναμικού πίνακα δεικτών σε αντικείμενα Student
    //(χρήση δεικτών επειδή η κλάση δεν έχει default constructor)
    Student** students = new Student*[3];

    //Εισαγωγή δεδομένων (Ελληνικοί και Λατινικοί χαρακτήρες)
    students[0] = new Student("21390123", "Νίκος Νικολόπουλος", "Άντρας", 3);
    students[1] = new Student("22390345", "Alex Smith"); //(Εξάμηνο 1 εξ ορισμού)
    students[2] = new Student(*students[0]); //Χρήση copy constructor
    students[2]->setFullname("Γεωργία Γεωργίου");
    students[2]->setAM("233390456");
    -*(students[2]); //Αλλαγή φύλου σε γυναίκα

    cout << "==============================================================" << endl;

    cout << "Πίνακας φοιτητών:" << std::endl;
    for (int i = 0; i < 3; i++) {
        cout << *students[i] << std::endl;
    }

    cout << "==============================================================" << endl;

/*
    // Επίδειξη λειτουργιών προηγούμενης άσκησης
    cout << "\nΕπίδειξη Λειτουργιών:" << std::endl;
    
    // Test ++ (Prefix)
    ++(*students[1]);
    cout << "Alex Smith μετά από ++: " << *students[1] << std::endl;

    // Test +=
    *students[0] += 2;
    cout << "Νίκος Νικολόπουλος μετά από += 2: " << *students[0] << std::endl;

    // Test --
    *students[0] -= 1;
    cout << "Νίκος Νικολόπουλος μετά από -= 1: " << *students[0] << std::endl;

*/

    // Δημιουργία δυναμικού πίνακα δεικτών σε αντικείμενα Professor
    // (χρήση δεικτών επειδή η κλάση δεν έχει default constructor)
    Professor** professors = new Professor*[3];
    
    // Εισαγωγή δεδομένων
    professors[0] = new Professor ("1232000", "Ελευθέριος Αυστηρός", "Άντρας", "Προγραμματιστής");
    professors[1] = new Professor ("3453000", "Κωνσταντίνα Καλούλα", "Γυναίκα", "Μαθηματικός");
    professors[2] = new Professor ("5674000", "Ιωάννης Δίκαιος", "Άντρας", "Φυσικός");


    cout << "==============================================================" << endl;

    cout << "Πίνακας καθηγητών:" << std::endl;
    for (int i = 0; i < 3; i++) {
        cout << *professors[i] << std::endl;
    }

    cout << "==============================================================" << endl;


    // Σύνθεση / Composition
    services.createCourse(Course("ICE-2000", "Εφαρμοσμένα Μαθηματικά", 4, professors[1]));
    services.createCourse(Course ("ICE-3000", "Αντικειμενοστρεφής Προγρραμματισμός", 2, professors[0]));
    services.createCourse(Course ("ICE-4000", "Φυσική", 6, professors[2]));
    services.updateCourse("ICE-2000", "ICE-1000", "Εφαρμοσμένα Μαθηματικά", 4, professors[1]);

    vector<Course> courses = services.getCourses();

    cout << "==============================================================" << endl;

    cout << "Πίνακας μαθημάτων:" << std::endl;
    for (int i = 0; i < 3; i++)
    {
        cout << courses[i] << std::endl;
    }

        cout << "==============================================================" << endl;
        // Δήλωση μαθημάτων που παρακολουθούν οι φοιτητές
        students[0]->addCourse(courses[1]);
        students[0]->addCourse(courses[2]);
        students[0]->addCourse(courses[2]);


        students[1]->addCourse(courses[2]);
        students[1]->addCourse(courses[2]);

        students[2]->addCourse(courses[0]);
        students[2]->addCourse(courses[1]);

    cout << "==============================================================" << endl;


    // Εμφάνιση όλων των μαθημάτων που παρακολουθεί ο κάθε φοιτητής
    for (int i = 0; i < 3; i++)
    {
        std::cout <<"Τα μαθήματα που παρακολουθεί " 
                  <<((students[i]->isFemale())? "η φοιτήτρια ": "ο φοιτητής " ) // Φυλετική διάκριση
                  << students[i]->getFullname() << ':' << std::endl;
        
        students[i]->printCourses();
        cout << "==============================================================" << endl;

    }

    // Δήλωση μαθημάτων που διδάσκουν οι καθηγητές
    professors[0]->addCourse(courses[0]);
    professors[0]->addCourse(courses[1]);


    professors[1]->addCourse(courses[0]);
    professors[1]->addCourse(courses[2]);
    professors[1]->addCourse(courses[2]);



    professors[2]->addCourse(courses[1]);
    professors[2]->addCourse(courses[2]);
    professors[2]->addCourse(courses[2]);


    cout << "==============================================================" << endl;


    // Εμφάνιση όλων των μαθημάτων που παρακολουθεί ο κάθε φοιτητής
    for (int i = 0; i < 3; i++)
    {
        std::cout <<"Τα μαθήματα που διδάσκει "
                  << ((professors[i]->isFemale())? "η καθηγήτρια ": "ο καθηγητής " ) // Φυλετική διάκριση
                  << professors[i]->getFullname() << ':' << std::endl;
       
        professors[i]->printCourses();   
        cout << "==============================================================" << endl;
    }
    cout << "==============================================================" << endl;

    professors[2]->removeCourse(courses[2]);
            std::cout <<"Τα μαθήματα που διδάσκει "
                  << ((professors[2]->isFemale())? "η καθηγήτρια ": "ο καθηγητής " ) // Φυλετική διάκριση
                  << professors[2]->getFullname() 
                  << " μετά από την αφαίρεση ενός μαθήματος:" << std::endl;
    professors[2]->printCourses();   
    cout << "==============================================================" << endl;


    for (int i = 0; i < 3 ; i++)
    {
        services.addPerson(*students[i]);
    }

    for (int i = 0; i < 3 ; i++)
    {
        services.addPerson(*professors[i]);
    }

    
    // services.removePerson(*professors[2]);
    cout << "Τα άτομα που βρίσκονται στο φοιτητολόγιο:" << endl;
    services.printPersons();
    
    // services.removeCourse(courses[2]);
    cout << "Τα μαθήματα που βρίσκονται στο φοιτητολόγιο:" << endl;
    services.printCourses();
    
    cout << "==============================================================" << endl;
    services.sendEmailToAllProfessors();
    cout << "==============================================================" << endl;
    services.sendEmailToAllStudents();
    cout << "==============================================================" << endl;




    // Αποδέσμευση μνήμης
    for (int i = 0; i < 3; i++) {
        delete students[i];
    }
    delete[] students;

    
    for (int i = 0; i < 3; i++)
    {
        delete professors[i];
    }
    delete[] professors;
    
    
    return 0;
}